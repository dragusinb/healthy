from .regina_maria import ReginaMariaCrawler
from .synevo import SynevoCrawler

__all__ = ["ReginaMariaCrawler", "SynevoCrawler"]
