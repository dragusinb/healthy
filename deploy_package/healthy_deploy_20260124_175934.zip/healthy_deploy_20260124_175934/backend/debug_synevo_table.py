import sys
import os
import pdfplumber
from processors.core.table_engine import HeaderDrivenTableExtractor, TableConfig

# Setup manually
config = TableConfig(
    headers={
        "name": ["Denumire", "Analiza", "Test"],
        "result": ["Rezultat", "Valoare"],
        "unit": ["UM", "U.M.", "Unit"],
        "reference": ["Interval", "Referinta", "Biologic"]
    },
    row_tolerance=5,
    footer_keywords=["Medic", "Rezultat eliberat", "Pagina", "Synevo", "Laborator"]
)

extractor = HeaderDrivenTableExtractor(config)

file_path = "../data/raw/synevo/31033112056.pdf"
print(f"Inspecting {file_path}")

with pdfplumber.open(file_path) as pdf:
    for i, page in enumerate(pdf.pages):
        print(f"--- Page {i+1} ---")
        words = page.extract_words()
        print(f"Total words: {len(words)}")
        
        # Manually try to find headers
        # We can't easily peek into extractor without modifying it, 
        # but we can try to see if headers exist in words.
        
        found_headers = []
        for key, candidates in config.headers.items():
            for w in words:
                if w['text'] in candidates:
                    found_headers.append((key, w['text'], w['top']))
                    
        print("Potential Headers found in words:")
        for h in found_headers:
            print(h)
            
        rows = extractor.extract(page)
        print(f"Extracted Rows: {len(rows)}")
