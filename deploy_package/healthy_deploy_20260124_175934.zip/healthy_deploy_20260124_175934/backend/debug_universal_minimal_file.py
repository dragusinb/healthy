from backend.processors.universal import UniversalTableParser
from backend.processors.registry import get_parser_config
import traceback

def run():
    try:
        config = get_parser_config("synevo")
        parser = UniversalTableParser("synevo", config)
        file_path = "data/raw/synevo/31033112056.pdf"
        
        result = parser.parse(file_path)
        
        with open("debug_result.txt", "w") as f:
            f.write(str(result))
            
    except Exception:
        with open("error_log.txt", "w") as f:
            f.write(traceback.format_exc())

if __name__ == "__main__":
    run()
