from fastapi.testclient import TestClient
from backend.main import app
import sys

# Force UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')

client = TestClient(app)

def test_endpoint(url):
    print(f"\n--- Testing GET {url} ---")
    try:
        response = client.get(url)
        print(f"Status Code: {response.status_code}")
        if response.status_code == 500:
            print("CRASH DETECTED!")
            # TestClient usually prints traceback to stderr, but let's try to print text
            print(response.text)
        else:
            print(f"Success. First 100 chars: {response.text[:100]}")
    except Exception as e:
        print(f"EXCEPTION: {e}")

if __name__ == "__main__":
    test_endpoint("/documents")
    test_endpoint("/results")
    test_endpoint("/insights")
