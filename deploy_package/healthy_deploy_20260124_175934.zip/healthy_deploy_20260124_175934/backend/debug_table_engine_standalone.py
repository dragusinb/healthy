import pdfplumber
from backend.processors.core.table_engine import HeaderDrivenTableExtractor, TableConfig

def run():
    path = "data/raw/synevo/31033112056.pdf"
    
    # Inline Config (Synevo)
    config = TableConfig(
        headers={
            "name": ["Denumire", "Analiza", "Test"],
            "result": ["Rezultat", "Valoare", "Rezultatele"], # Added Rezultatele just in case
            "unit": ["UM", "U.M.", "Unit"],
            "reference": ["Interval", "Referinta", "Biologic"]
        },
        row_tolerance=10,
        footer_keywords=["Medic", "Pagina"]
    )
    
    extractor = HeaderDrivenTableExtractor(config)
    
    with pdfplumber.open(path) as pdf:
        page = pdf.pages[0]
        print(f"DEBUG: Processing Page 0. Width={page.width}")
        
        words = page.extract_words()
        print(f"DEBUG: Word Count: {len(words)}")
        
        # Look for headers manually
        found_denumire = any("denumire" in w['text'].lower() for w in words)
        found_rezultat = any("rezultat" in w['text'].lower() for w in words)
        print(f"DEBUG: 'Denumire' present? {found_denumire}")
        print(f"DEBUG: 'Rezultat' present? {found_rezultat}")
        
        # Run Extractor
        rows = extractor.extract(page)
        print(f"DEBUG: Extracted {len(rows)} rows.")
        for r in rows:
            print(f" -- {r}")

if __name__ == "__main__":
    run()
