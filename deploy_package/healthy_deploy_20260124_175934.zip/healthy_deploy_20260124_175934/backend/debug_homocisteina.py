from backend.database import SessionLocal
from backend.models import TestResult

db = SessionLocal()
results = db.query(TestResult).filter(TestResult.test_name.like('%HOMOCISTEINA%')).all()

print(f"Total found: {len(results)}")
for r in results:
    print(f"ID: {r.id}, Name: '{r.test_name}', Value: {r.value}, Date: {r.document.document_date}")
