from backend.processors.universal import UniversalTableParser
from backend.processors.registry import get_parser_config

def run():
    print("DEBUG: Starting minimal debug run.")
    config = get_parser_config("synevo")
    if not config:
        print("ERROR: Config not found!")
        return

    parser = UniversalTableParser("synevo", config)
    file_path = "data/raw/synevo/31033112056.pdf"
    
    try:
        res = parser.parse(file_path)
        print(f"DEBUG: Parse complete. Keys: {res.keys()}")
        print(f"DEBUG: Results count: {len(res.get('results', []))}")
        for r in res.get('results', []):
            print(f" -- {r['test_name']}: {r['value']}")
    except Exception as e:
        print(f"CRASH: {e}")

if __name__ == "__main__":
    run()
