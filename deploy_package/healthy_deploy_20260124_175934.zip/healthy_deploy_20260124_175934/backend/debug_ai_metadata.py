from backend.processors.ai_parser import AIParser
import pdfplumber
import json
import os

# Hardcoded key
# OPENAI_API_KEY loaded from .env

def check():
    path = r"c:\OldD\_Projects\Healthy\data\raw\regina_maria\rezultat_8245707_2025.12.08 07.39.06.pdf"
    
    print(f"--- Processing {os.path.basename(path)} ---")
    
    text_content = ""
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text_content += page.extract_text() or ""
            
    print("\n--- RAW TEXT START ---")
    print(text_content[:600])
    print("--- RAW TEXT END ---\n")
    
    parser = AIParser()
    result = parser.parse_text(text_content)
    
    print("\n--- AI RESPONSE ---")
    print(json.dumps(result.get("metadata", {}), indent=2))

if __name__ == "__main__":
    check()
