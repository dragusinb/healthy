import asyncio
import os
from sqlalchemy.orm import Session
from backend_v2.database import SessionLocal
from backend_v2.models import User, LinkedAccount
from backend_v2.services.crawlers_manager import run_regina_async

async def debug_regina():
    db = SessionLocal()
    user = db.query(User).filter(User.email == "dragusinb@gmail.com").first()
    if not user:
        print("User not found")
        return

    link = db.query(LinkedAccount).filter(
        LinkedAccount.user_id == user.id,
        LinkedAccount.provider_name == "Regina Maria"
    ).first()

    if not link:
        print("Regina Maria link not found for user")
        return
    
    print(f"Found link for user: {link.username}")
    with open("creds_dump.log", "w") as f:
         f.write(f"{link.username}\n{link.encrypted_password}")
    print("Starting crawler...")
    
    # Run the crawler
    result = await run_regina_async(link.username, link.encrypted_password)
    print(f"Result: {result}")

if __name__ == "__main__":
    asyncio.run(debug_regina())
