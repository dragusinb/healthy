# Healthy - Installation Guide

## Prerequisites
- Ubuntu 22.04+ or similar Linux distribution
- Python 3.11+
- Node.js 18+
- PostgreSQL 14+
- Nginx

## Server Setup

### 1. System Packages
```bash
sudo apt update
sudo apt install -y python3.11 python3.11-venv python3-pip nodejs npm postgresql nginx xvfb
```

### 2. Database Setup
```bash
sudo -u postgres psql
CREATE DATABASE healthy;
CREATE USER healthy WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE healthy TO healthy;
\q
```

### 3. Backend Setup
```bash
cd /opt/healthy/backend_v2
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
playwright install chromium
playwright install-deps

# Copy and edit environment file
cp .env.example .env
nano .env  # Add your API keys and database URL

# Initialize database
python -c "from database import engine, Base; Base.metadata.create_all(engine)"
```

### 4. Frontend Setup
```bash
cd /opt/healthy/frontend_v2
npm install
cp .env.example .env.production
nano .env.production  # Set your API URL
npm run build
```

### 5. Systemd Service
Create `/etc/systemd/system/healthy-api.service`:
```ini
[Unit]
Description=Healthy API Backend
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/healthy/backend_v2
Environment="PATH=/opt/healthy/backend_v2/venv/bin"
ExecStart=/opt/healthy/backend_v2/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable healthy-api
sudo systemctl start healthy-api
```

### 6. Nginx Configuration
Create `/etc/nginx/sites-available/healthy`:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    root /opt/healthy/frontend_v2/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~ ^/(auth|users|dashboard|documents|health|biomarkers|admin|evolution)(/|$) {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location = /health {
        proxy_pass http://127.0.0.1:8000;
    }
}
```

Enable:
```bash
sudo ln -s /etc/nginx/sites-available/healthy /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 7. SSL with Let's Encrypt
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### 8. Create Admin User
```bash
cd /opt/healthy/backend_v2
source venv/bin/activate
python -c "
from database import SessionLocal, engine
from models import User, Base
from auth.security import get_password_hash

Base.metadata.create_all(engine)
db = SessionLocal()
admin = User(
    email='admin@example.com',
    hashed_password=get_password_hash('your_password'),
    is_admin=True
)
db.add(admin)
db.commit()
print('Admin user created!')
"
```

## Verification
1. Check API: `curl https://your-domain.com/health`
2. Open browser: `https://your-domain.com`
3. Login with admin credentials

## Troubleshooting
- Check API logs: `journalctl -u healthy-api -f`
- Check Nginx logs: `tail -f /var/log/nginx/error.log`
- Database connection: `PGPASSWORD=xxx psql -h localhost -U healthy -d healthy`
