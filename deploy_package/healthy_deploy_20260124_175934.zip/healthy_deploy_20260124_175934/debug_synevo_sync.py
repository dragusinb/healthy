import asyncio
import os
from sqlalchemy.orm import Session
from backend_v2.database import SessionLocal
from backend_v2.models import User, LinkedAccount
from backend_v2.services.crawlers_manager import run_synevo_async

async def debug_synevo():
    db = SessionLocal()
    user = db.query(User).filter(User.email == "dragusinb@gmail.com").first()
    if not user:
        print("User not found")
        return

    link = db.query(LinkedAccount).filter(
        LinkedAccount.user_id == user.id,
        LinkedAccount.provider_name == "Synevo"
    ).first()

    if not link:
        print("Synevo link not found for user")
        return
    
    print(f"Found link for user: {link.username}")
    print("Starting crawler...")
    
    # Run the crawler
    # Inspecting crawler_service.py showed it uses run_synevo_async
    result = await run_synevo_async(link.username, link.encrypted_password)
    print(f"Result: {result}")

if __name__ == "__main__":
    asyncio.run(debug_synevo())
