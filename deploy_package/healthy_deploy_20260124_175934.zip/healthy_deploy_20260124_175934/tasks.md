# Healthy - Active Tasks

## In Progress

### Generate Clean Deployment Package
**Status:** In Progress
**Priority:** High

Create a ZIP file containing the app without any user data (no documents, no database data) for fresh installation on another server.

**Requirements:**
- [ ] Include all source code (backend_v2, frontend_v2)
- [ ] Include configuration templates (not actual .env files with secrets)
- [ ] Include deployment scripts/instructions
- [ ] Exclude: data/, uploads/, *.db, .env files, __pycache__, node_modules
- [ ] Document installation steps

---

## Pending

### Data Isolation Audit
**Status:** Pending
**Priority:** HIGH - Security

Ensure every user only sees their own data. Review all endpoints.

**Issues Found:**
- Profile scan extracted "Dumitru Niculescu" name from documents belonging to someone else
- Need to verify document ownership matches linked account credentials

**Actions:**
- [ ] Audit all API endpoints for proper user_id filtering
- [ ] Add validation that imported docs match the user's own medical records
- [ ] Consider adding document owner name verification

### Localization - Romanian Default
**Status:** Pending
**Priority:** Medium
- Full i18n with language selector
- Romanian as default language

### Admin Dashboard Enhancements
**Status:** Pending
**Priority:** Medium
- Server metrics (CPU, RAM, disk)
- Error logs viewer

### Gap Analysis / Recommended Screenings
**Status:** Pending
**Priority:** High

Add a "Gap Analysis" section that recommends what tests the user should do based on:
- Age (e.g., colonoscopy after 50, mammogram recommendations)
- Gender-specific screenings
- Medical history/chronic conditions
- Time since last test for key biomarkers
- Risk factors from profile (smoking, obesity, family history)

**Features:**
- [ ] AI-generated recommended screenings list
- [ ] Recommended frequency for each test
- [ ] Priority levels (urgent, recommended, optional)
- [ ] Track when tests were last done
- [ ] Notifications when screenings are due

### AI Reports - Consider Data Age/Evolution
**Status:** Pending
**Priority:** Medium

When generating AI health reports, the analysis should:
- Take into account the AGE of biomarker data (old values might be outdated)
- Consider the EVOLUTION/trend of biomarkers over time
- Note when an abnormal value has since normalized (condition may be resolved)
- Flag when data is stale and recommend re-testing

### Report History & Comparison
**Status:** Pending
**Priority:** Medium
- List all past reports
- Compare two reports side-by-side

### Database Backups
**Status:** Pending
**Priority:** Medium
- pg_dump cron job
- Cloud backup solution

---

## Completed

- [x] Fix server - orphan process blocking port 8000
- [x] Update login text to "Toate analizele tale intr-un singur loc"
- [x] Create .env.production with correct API URL
- [x] Deploy frontend with HTTPS API URL
- [x] Profile extraction feature already implemented (backend + frontend)
- [x] Clear wrong profile data (Dumitru Niculescu) from user 1

---

*Last updated: 2026-01-24*
