from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

try:
    print("Testing 'J@guar123'...")
    h = pwd_context.hash("J@guar123")
    print(f"Hash: {h}")
    print("Verification:", pwd_context.verify("J@guar123", h))
except Exception as e:
    print(f"Error: {e}")

try:
    print("Testing empty string...")
    pwd_context.hash("")
except Exception as e:
    print(f"Error empty: {e}")

try:
    print("Testing None...")
    pwd_context.hash(None)
except Exception as e:
    print(f"Error None: {e}")
